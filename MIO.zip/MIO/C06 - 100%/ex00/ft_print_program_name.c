/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_program_name.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimartin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/07 15:13:33 by gimartin          #+#    #+#             */
/*   Updated: 2021/12/08 12:36:48 by gimartin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putstr(char *str)
{
	int	cont;

	cont = 0;
	while (*(str + cont) != '\0')
	{
		write(1, (str + cont), 1);
		cont++;
	}
	write(1, "\n", 1);
}

int	main(int argc, char **argv)
{
	if (argc != 0)
		ft_putstr(argv[0]);
	return (0);
}
