/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimartin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/02 08:19:36 by gimartin          #+#    #+#             */
/*   Updated: 2021/12/06 16:30:43 by gimartin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	curr(char *c, int i)
{
	int	neg;

	neg = 1;
	while ((c[i] >= 9 && c[i] <= 13) || c[i] == 32)
	{
		i++;
	}
	while (c[i] == 45 || c[i] == 43)
	{
		if (c[i] == 45)
			neg *= -1;
		i++;
	}
	i *= neg;
	return (i);
}

int	numb(char *str, int i, int n)
{
	int	num;
	int	real;
	int	j;

	num = 0;
	j = 0;
	while (str[i] >= '0' && str[i] <= '9' && j < 9)
	{
		num += str[i] - 48;
		num *= 10;
		i++;
		j++;
	}
	real = num * n;
	if (num >= 1000000000 && ((str[i] >= '0' && str[i] <= '9')))
		real += (str[i] - 48) * n;
	else
		real /= 10;
	return (real);
}

int	ft_atoi(char *str)
{
	int	i;
	int	num;
	int	sig;

	i = curr(str, 0);
	num = 0;
	sig = 1;
	if (i < 0)
	{
		i *= -1;
		sig = -1;
	}
	num = numb(str, i, sig);
	return (num);
}
