/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimartin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/03 09:22:31 by gimartin          #+#    #+#             */
/*   Updated: 2021/12/06 16:32:07 by gimartin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	ft_strcmp(char *s1, char *s2)
{
	while (*s1 == *s2)
	{
		if (*s1++ == 0)
			return (0);
	s2++;
	}
	return (*s1 - *s2);
}

int	check(char *base)
{
	if (ft_strcmp(base, "0123456789") == 0)
		return (1);
	if (ft_strcmp(base, "01") == 0)
		return (1);
	if (ft_strcmp(base, "0123456789abcdef") == 0)
		return (1);
	if (ft_strcmp(base, "poneyvif") == 0)
		return (1);
	return (0);
}

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != 0)
	{
		i++;
	}
	return (i);
}

void	ft_putnbr_base(int nbr, char *base)
{
	if (check(base))
	{
		if (nbr < 0)
		{
			ft_putchar('-');
			nbr *= -1;
		}
		if (nbr / ft_strlen(base) != 0)
		{
			ft_putnbr_base((nbr / ft_strlen(base)), base);
			ft_putnbr_base((nbr % ft_strlen(base)), base);
		}
		else
		{
			if (ft_strcmp(base, "poneyvif") == 0)
				base = "01234567";
			ft_putchar(base[nbr % ft_strlen(base)]);
		}
	}
}
