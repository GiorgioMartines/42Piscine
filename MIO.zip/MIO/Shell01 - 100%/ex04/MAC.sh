ifconfig | awk '/ether/ {print $NF}'
