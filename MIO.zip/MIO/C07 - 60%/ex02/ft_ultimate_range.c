/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimartin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/08 10:35:37 by gimartin          #+#    #+#             */
/*   Updated: 2021/12/15 09:30:15 by gimartin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	*base;
	int	size;
	int	i;

	i = 0;
	if (min >= max)
	{
		range = NULL;
		return (0);
	}
	size = max - min;
	if (size < 0)
		size *= -1;
	base = malloc(sizeof(int) * size);
	if (!base)
		return (-1);
	while (i < size)
	{
		base[i] = min;
		i++;
		min++;
	}
	*range = base;
	return (i);
}
