/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimartin <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/08 11:29:25 by gimartin          #+#    #+#             */
/*   Updated: 2021/12/15 09:36:01 by gimartin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != 0)
	{
		i++;
	}
	return (i);
}

char	*ft_strcpy(char *dest, char *src)
{
	int	cont;

	cont = 0;
	while (src[cont] != 0)
	{
		dest[cont] = src[cont];
		cont++;
	}
	dest[cont] = src[cont];
	return (dest);
}

char	*ft_strdup(char *src)
{
	char	*base;
	int		i;

	i = ft_strlen(src);
	base = malloc(sizeof(char) * i);
	base = ft_strcpy(base, src);
	return (base);
}
